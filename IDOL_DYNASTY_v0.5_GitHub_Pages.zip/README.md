# IDOL DYNASTY v0.5 - GitHub Pages Edition

このフォルダの中身を GitHub リポジトリのルート直下にアップロードすれば、そのまま GitHub Pages で遊べます。

## 必須ファイル
- index.html
- style.css
- game.js
- .nojekyll

## GitHub Pages 公開手順

1. GitHubで新しいリポジトリを作成
2. このフォルダ内の4ファイルをリポジトリ直下へアップロード
3. GitHubのリポジトリで `Settings`
4. 左メニューから `Pages`
5. `Build and deployment` の Source を `Deploy from a branch`
6. Branch を `main`
7. Folder を `/ (root)`
8. `Save`

公開後のURLは通常、

`https://ユーザー名.github.io/リポジトリ名/`

になります。

## 注意
- `index.html` は必ずリポジトリの一番上に置いてください。
- ZIPファイルのままGitHubへ置くのではなく、解凍した中身をアップロードしてください。
- セーブデータはブラウザの localStorage に保存されます。
